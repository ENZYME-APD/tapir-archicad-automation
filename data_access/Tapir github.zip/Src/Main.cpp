// *****************************************************************************
// Contact person:	Tibor Lorántfy (tlorantfy@graphisoft.com)
// *****************************************************************************

#include	"APIEnvir.h"
#include	"ACAPinc.h"		// also includes APIdefs.h

#include	"AdditionalJSONCommands.hpp"
#include    "APIcommon.h"
#include	"DGTestResIDs.hpp"


// =============================================================================
//
// Required functions
//
// =============================================================================

// -----------------------------------------------------------------------------
// Dependency definitions
// -----------------------------------------------------------------------------

API_AddonType	__ACDLL_CALL	CheckEnvironment (API_EnvirParams* envir)
{
	RSGetIndString (&envir->addOnInfo.name, 32000, 1, ACAPI_GetOwnResModule ());
	RSGetIndString (&envir->addOnInfo.description, 32000, 2, ACAPI_GetOwnResModule ());

	return APIAddon_Preload;
}		// CheckEnvironment


// -----------------------------------------------------------------------------
// Interface definitions
// -----------------------------------------------------------------------------

GSErrCode	__ACDLL_CALL	RegisterInterface (void)
{
	return NoError;
}		// RegisterInterface


// -----------------------------------------------------------------------------
// Initialize
//		called after the Add-On has been loaded into memory
// -----------------------------------------------------------------------------

GSErrCode __ACENV_CALL	Initialize (void)
{
	GSErrCode err;

	err = ACAPI_Install_AddOnCommandHandler (GS::NewOwned<PublishCommand> ());
	if (err)
		ACAPI_WriteReport("Publish AddOn Failed %s", true, ErrID_To_Name(err));
	err = ACAPI_Install_AddOnCommandHandler (GS::NewOwned<TeamworkReceiveCommand> ());
	if (err)
		ACAPI_WriteReport("TeamWprk AddOn Failed %s", true, ErrID_To_Name(err));
	err = ACAPI_Install_AddOnCommandHandler (GS::NewOwned<GetProjectInfoCommand> ());
	if (err)
		ACAPI_WriteReport("ProjectInfo AddOn Failed %s", true, ErrID_To_Name(err));
	err = ACAPI_Install_AddOnCommandHandler (GS::NewOwned<GetArchicadLocationCommand> ());
	if (err)
		ACAPI_WriteReport("Location AddOn Failed %s", true, ErrID_To_Name(err));
	err = ACAPI_Install_AddOnCommandHandler (GS::NewOwned<QuitCommand> ());
	if (err)
		ACAPI_WriteReport("Quit AddOn Failed %s", true, ErrID_To_Name(err));
	err = ACAPI_Install_AddOnCommandHandler (GS::NewOwned<ReloadLibrariesCommand> ());
	if (err)
		ACAPI_WriteReport("Reload Libraries AddOn Failed %s", true, ErrID_To_Name(err));

	
	err = ACAPI_Install_AddOnCommandHandler (GS::NewOwned<UtilityCommand>());
	if (err)
		ACAPI_WriteReport("Data Access AddOn Failed %s", true, ErrID_To_Name(err));
    //*/
	return err;
}		// Initialize


// -----------------------------------------------------------------------------
// FreeData
//		called when the Add-On is going to be unloaded
// -----------------------------------------------------------------------------

GSErrCode __ACENV_CALL	FreeData (void)
{
	return NoError;
}		// FreeData
