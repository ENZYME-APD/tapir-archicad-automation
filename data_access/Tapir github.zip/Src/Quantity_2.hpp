#pragma once
void GetDoorQuantities(GS::UniString value, API_QuantitiesMask& mask, int& index);
void GetWindowQuantities(GS::UniString value, API_QuantitiesMask& mask, int& index);
//GSErrCode GetQuantityMask(GS::UniString elementType, GS::UniString value, API_QuantitiesMask& mask, int& index);
